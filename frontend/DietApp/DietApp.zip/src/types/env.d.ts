declare module '@env' {
  export const EXPO_PUBLIC_BASE_URL: string;
}
